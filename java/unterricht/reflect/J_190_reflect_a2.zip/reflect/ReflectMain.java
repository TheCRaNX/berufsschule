package reflect;

import java.lang.reflect.*;

public class ReflectMain {

	public static void main(String[] args) {
		// TODO J_190_A2

	}

}
